package com.example.videosaver

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.format.DateUtils
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity() {
    /** A link shared into the app (Share → Video Saver) waiting to be saved. */
    private val incomingUrl = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) incomingUrl.value = extractUrl(intent)
        setContent {
            VideoSaverTheme {
                VideoSaverApp(
                    incomingUrl = incomingUrl.value,
                    onIncomingHandled = { incomingUrl.value = null }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractUrl(intent)?.let { incomingUrl.value = it }
    }
}

private val urlRegex = Regex("https?://\\S+", RegexOption.IGNORE_CASE)

/** Pulls the first link out of shared text or an "Open with" request. */
internal fun extractUrl(intent: Intent?): String? {
    if (intent == null) return null
    val raw = when (intent.action) {
        Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
        Intent.ACTION_VIEW -> intent.dataString
        else -> null
    } ?: return null
    return urlRegex.find(raw)?.value?.trimEnd(')', ']', '.', ',', '"', '\'')
}

private fun isYouTubeHost(host: String): Boolean =
    listOf("youtube.com", "youtu.be", "youtube-nocookie.com").any { host == it || host.endsWith(".$it") }

@Composable
fun VideoSaverTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val context = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun VideoSaverApp(incomingUrl: String?, onIncomingHandled: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { VideoRepository(context) }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var url by rememberSaveable { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(repo.loadHistory()) }
    var pendingDelete by remember { mutableStateOf<SavedVideo?>(null) }

    // Save the history whenever it changes.
    LaunchedEffect(history) { repo.saveHistory(history) }

    // Keep download progress up to date (faster while something is downloading).
    LaunchedEffect(Unit) {
        while (true) {
            val ids = history.filter { it.state != DownloadState.Missing }.map { it.downloadId }
            val snapshots = repo.query(ids)
            if (snapshots != null && ids.isNotEmpty()) {
                val finished = mutableListOf<DownloadSnapshot>()
                history = history.map { item ->
                    val snap = snapshots[item.downloadId]
                    when {
                        item.downloadId !in ids -> item
                        snap == null -> item.copy(state = DownloadState.Missing)
                        else -> {
                            if (snap.state == DownloadState.Successful && item.state != DownloadState.Successful) {
                                finished += snap
                            }
                            item.copy(
                                state = snap.state,
                                bytesDownloaded = snap.bytesDownloaded,
                                totalBytes = snap.totalBytes,
                                failureReason = snap.reason
                            )
                        }
                    }
                }
                finished.forEach { repo.scanIntoGallery(it) }
            }
            delay(if (history.any { it.isActive }) 700L else 3000L)
        }
    }

    fun startSave(input: String) {
        val uri = Uri.parse(input.trim())
        val host = uri.host?.lowercase().orEmpty()
        if (uri.scheme?.lowercase() !in setOf("http", "https") || host.isBlank()) {
            message = "Enter a full link that starts with https://"
            return
        }
        if (isYouTubeHost(host)) {
            message = try {
                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                "YouTube links open in the YouTube app. Use YouTube's own Download button to watch offline."
            } catch (_: ActivityNotFoundException) {
                "Couldn't open this YouTube link."
            }
            return
        }
        checking = true
        message = "Checking the link…"
        scope.launch {
            when (val result = repo.checkLink(uri)) {
                is LinkCheck.Video -> {
                    message = try {
                        val item = repo.enqueue(uri, result)
                        history = listOf(item) + history
                        url = ""
                        "Saving to Gallery › $ALBUM_NAME. You can leave the app — it keeps downloading."
                    } catch (e: Exception) {
                        "Couldn't start the download: ${e.message ?: "unknown error"}"
                    }
                }
                is LinkCheck.Rejected -> message = result.reason
            }
            checking = false
        }
    }

    // Handle links shared into the app.
    LaunchedEffect(incomingUrl) {
        val shared = incomingUrl ?: return@LaunchedEffect
        url = shared
        startSave(shared)
        onIncomingHandled()
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "▶ Video Saver",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Save videos you're allowed to download straight into your Gallery album “$ALBUM_NAME”.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                Card(shape = RoundedCornerShape(18.dp)) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = url,
                            onValueChange = { url = it },
                            label = { Text("Video link") },
                            placeholder = { Text("https://example.com/video.mp4") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { clipboard.getText()?.text?.let { url = it.trim() } },
                                modifier = Modifier.weight(1f)
                            ) { Text("Paste") }
                            Button(
                                onClick = { startSave(url) },
                                enabled = !checking && url.isNotBlank(),
                                modifier = Modifier.weight(2f)
                            ) { Text(if (checking) "Checking…" else "Save to Gallery") }
                        }
                        Text(
                            "Tip: in your browser or another app, tap Share → Video Saver to save a link instantly.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            message?.let { msg ->
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer
                        )
                    ) {
                        Text(msg, modifier = Modifier.padding(16.dp))
                    }
                }
            }

            item {
                Text(
                    "Downloads",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            if (history.isEmpty()) {
                item {
                    Text(
                        "Nothing saved yet. Videos you save will show up here and in your Gallery.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(history, key = { it.downloadId }) { video ->
                    VideoCard(
                        video = video,
                        onPlay = { openVideo(context, repo, video)?.let { message = it } },
                        onShare = { shareVideo(context, repo, video)?.let { message = it } },
                        onDelete = { pendingDelete = video },
                        onCancel = {
                            repo.remove(video.downloadId)
                            history = history.filterNot { it.downloadId == video.downloadId }
                        },
                        onRetry = {
                            repo.remove(video.downloadId)
                            history = history.filterNot { it.downloadId == video.downloadId }
                            startSave(video.sourceUrl)
                        },
                        onRemove = {
                            repo.remove(video.downloadId)
                            history = history.filterNot { it.downloadId == video.downloadId }
                        }
                    )
                }
            }

            item {
                Text(
                    "Only save videos you own or have permission to download. YouTube links open in the YouTube app.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }

    pendingDelete?.let { video ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete video?") },
            text = { Text("“${video.title}” will be deleted from your phone and Gallery.") },
            confirmButton = {
                TextButton(onClick = {
                    repo.remove(video.downloadId)
                    history = history.filterNot { it.downloadId == video.downloadId }
                    pendingDelete = null
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun VideoCard(
    video: SavedVideo,
    onPlay: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onRemove: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                video.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "${Uri.parse(video.sourceUrl).host ?: video.sourceUrl} · " +
                    DateUtils.getRelativeTimeSpanString(video.createdAt),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                statusText(video),
                style = MaterialTheme.typography.bodySmall,
                color = if (video.state == DownloadState.Failed) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.onSurface
                }
            )
            if (video.isActive) {
                if (video.totalBytes > 0L) {
                    LinearProgressIndicator(progress = { video.progress }, modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                when (video.state) {
                    DownloadState.Successful -> {
                        TextButton(onClick = onPlay) { Text("Play") }
                        TextButton(onClick = onShare) { Text("Share") }
                        TextButton(onClick = onDelete) { Text("Delete") }
                    }
                    DownloadState.Pending, DownloadState.Running, DownloadState.Paused -> {
                        TextButton(onClick = onCancel) { Text("Cancel") }
                    }
                    DownloadState.Failed -> {
                        TextButton(onClick = onRetry) { Text("Retry") }
                        TextButton(onClick = onRemove) { Text("Remove") }
                    }
                    DownloadState.Missing -> {
                        TextButton(onClick = onRemove) { Text("Remove") }
                    }
                }
            }
        }
    }
}

private fun statusText(video: SavedVideo): String = when (video.state) {
    DownloadState.Pending -> "Waiting to start…"
    DownloadState.Running -> if (video.totalBytes > 0L) {
        "Downloading ${(video.progress * 100).toInt()}% · ${formatSize(video.bytesDownloaded)} of ${formatSize(video.totalBytes)}"
    } else {
        "Downloading · ${formatSize(video.bytesDownloaded)}"
    }
    DownloadState.Paused -> "Paused — waiting for a connection"
    DownloadState.Successful -> "Saved · ${formatSize(video.totalBytes)} · Gallery › $ALBUM_NAME"
    DownloadState.Failed -> "Failed: ${failureText(video.failureReason)}"
    DownloadState.Missing -> "No longer on this phone"
}

private fun failureText(reason: Int): String = when (reason) {
    DownloadManager.ERROR_INSUFFICIENT_SPACE -> "not enough storage space"
    DownloadManager.ERROR_DEVICE_NOT_FOUND -> "storage not available"
    DownloadManager.ERROR_CANNOT_RESUME -> "the download couldn't resume"
    DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "too many redirects"
    DownloadManager.ERROR_HTTP_DATA_ERROR -> "network error"
    DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "a file with this name already exists"
    in 400..599 -> "the website refused it (HTTP $reason)"
    else -> "error $reason"
}

private fun formatSize(bytes: Long): String {
    if (bytes <= 0L) return "—"
    val units = listOf("B", "KB", "MB", "GB")
    var value = bytes.toDouble()
    var unit = 0
    while (value >= 1024 && unit < units.lastIndex) {
        value /= 1024
        unit++
    }
    return if (unit == 0) "$bytes B" else String.format(Locale.US, "%.1f %s", value, units[unit])
}

/** Returns an error message, or null on success. */
private fun openVideo(context: Context, repo: VideoRepository, video: SavedVideo): String? {
    val uri = repo.fileUri(video.downloadId) ?: return "Couldn't find this video on your phone."
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, repo.mimeType(video.downloadId) ?: "video/*")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    return try {
        context.startActivity(intent)
        null
    } catch (_: ActivityNotFoundException) {
        "No video player app found."
    }
}

/** Returns an error message, or null on success. */
private fun shareVideo(context: Context, repo: VideoRepository, video: SavedVideo): String? {
    val uri = repo.fileUri(video.downloadId) ?: return "Couldn't find this video on your phone."
    val send = Intent(Intent.ACTION_SEND)
        .setType(repo.mimeType(video.downloadId) ?: "video/*")
        .putExtra(Intent.EXTRA_STREAM, uri)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    return try {
        context.startActivity(Intent.createChooser(send, "Share video"))
        null
    } catch (_: ActivityNotFoundException) {
        "No app available to share with."
    }
}
