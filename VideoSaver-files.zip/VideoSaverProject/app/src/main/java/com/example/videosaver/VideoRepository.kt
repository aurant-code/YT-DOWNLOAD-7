package com.example.videosaver

import android.app.DownloadManager
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Gallery album name. Files are saved in Movies/Video Saver. */
const val ALBUM_NAME = "Video Saver"
private const val USER_AGENT = "VideoSaver/2.0 (Android)"
private const val KEY_HISTORY = "history"

enum class DownloadState { Pending, Running, Paused, Successful, Failed, Missing }

data class SavedVideo(
    val downloadId: Long,
    val title: String,
    val sourceUrl: String,
    val createdAt: Long,
    val state: DownloadState = DownloadState.Pending,
    val bytesDownloaded: Long = 0L,
    val totalBytes: Long = -1L,
    val failureReason: Int = 0
) {
    val isActive: Boolean
        get() = state == DownloadState.Pending || state == DownloadState.Running || state == DownloadState.Paused

    val progress: Float
        get() = if (totalBytes > 0L) (bytesDownloaded.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
}

data class DownloadSnapshot(
    val id: Long,
    val state: DownloadState,
    val bytesDownloaded: Long,
    val totalBytes: Long,
    val reason: Int,
    val localUri: String?,
    val mimeType: String?
)

sealed interface LinkCheck {
    data class Video(val fileName: String, val mimeType: String) : LinkCheck
    data class Rejected(val reason: String) : LinkCheck
}

class VideoRepository(context: Context) {
    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val prefs = appContext.getSharedPreferences("video_history", Context.MODE_PRIVATE)

    // ---------- History ----------

    fun loadHistory(): List<SavedVideo> {
        val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                SavedVideo(
                    downloadId = o.getLong("id"),
                    title = o.getString("title"),
                    sourceUrl = o.getString("url"),
                    createdAt = o.getLong("createdAt"),
                    state = runCatching { DownloadState.valueOf(o.optString("state")) }
                        .getOrDefault(DownloadState.Pending),
                    bytesDownloaded = o.optLong("bytes", 0L),
                    totalBytes = o.optLong("total", -1L),
                    failureReason = o.optInt("reason", 0)
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveHistory(items: List<SavedVideo>) {
        val array = JSONArray()
        items.forEach { v ->
            array.put(
                JSONObject()
                    .put("id", v.downloadId)
                    .put("title", v.title)
                    .put("url", v.sourceUrl)
                    .put("createdAt", v.createdAt)
                    .put("state", v.state.name)
                    .put("bytes", v.bytesDownloaded)
                    .put("total", v.totalBytes)
                    .put("reason", v.failureReason)
            )
        }
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
    }

    // ---------- Link checking ----------

    /** Confirms the link points to a single video file before downloading it. */
    suspend fun checkLink(uri: Uri): LinkCheck = withContext(Dispatchers.IO) {
        val fromPath = mimeFromExtension(MimeTypeMap.getFileExtensionFromUrl(uri.toString()))
        if (fromPath != null && fromPath.startsWith("video/")) {
            return@withContext LinkCheck.Video(buildFileName(uri, null, fromPath), fromPath)
        }

        val probeResult: ProbeResult? = try {
            probe(URL(uri.toString()))
        } catch (_: IOException) {
            null
        }
        val probe = probeResult ?: return@withContext LinkCheck.Rejected(
            "Couldn't reach this link. Check your internet connection and the address."
        )

        if (probe.code !in 200..299) {
            return@withContext LinkCheck.Rejected("The website refused this link (HTTP ${probe.code}).")
        }

        val mime = probe.contentType
        when {
            mime == null -> LinkCheck.Rejected(
                "This link doesn't say what kind of file it is. Use a direct link to a video file."
            )
            mime.startsWith("video/") -> LinkCheck.Video(buildFileName(uri, probe.disposition, mime), mime)
            mime.contains("mpegurl") || mime.contains("dash+xml") -> LinkCheck.Rejected(
                "This is a streaming playlist, not a single video file, so it can't be saved."
            )
            mime.startsWith("text/html") -> LinkCheck.Rejected(
                "This is a web page, not a video file. Copy the direct link to the video file instead."
            )
            else -> LinkCheck.Rejected("This link is a $mime file, not a video.")
        }
    }

    private data class ProbeResult(val code: Int, val contentType: String?, val disposition: String?)

    private fun probe(start: URL): ProbeResult? {
        var url = start
        var method = "HEAD"
        repeat(8) {
            var conn: HttpURLConnection? = null
            try {
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    instanceFollowRedirects = false
                    connectTimeout = 10_000
                    readTimeout = 10_000
                    setRequestProperty("User-Agent", USER_AGENT)
                    if (method == "GET") setRequestProperty("Range", "bytes=0-0")
                }
                val code = conn.responseCode
                val location = conn.getHeaderField("Location")
                when {
                    code in 300..399 && location != null -> url = URL(url, location)
                    method == "HEAD" && code in setOf(403, 405, 501) -> method = "GET"
                    else -> return ProbeResult(
                        code = code,
                        contentType = conn.contentType?.substringBefore(';')?.trim()?.lowercase(),
                        disposition = conn.getHeaderField("Content-Disposition")
                    )
                }
            } catch (_: IOException) {
                if (method == "GET") return null
                method = "GET"
            } finally {
                conn?.disconnect()
            }
        }
        return null
    }

    private fun mimeFromExtension(ext: String?): String? =
        ext?.lowercase()?.takeIf { it.isNotEmpty() }
            ?.let { MimeTypeMap.getSingleton().getMimeTypeFromExtension(it) }

    private fun buildFileName(uri: Uri, disposition: String?, mime: String): String {
        val guessed = URLUtil.guessFileName(uri.toString(), disposition, mime)
        val guessedExt = guessed.substringAfterLast('.', "").lowercase()
        val ext = if (mimeFromExtension(guessedExt)?.startsWith("video/") == true) {
            guessedExt
        } else {
            MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "mp4"
        }
        val base = guessed.substringBeforeLast('.')
            .replace(Regex("[^A-Za-z0-9._-]+"), "_")
            .trim('_', '.')
            .take(60)
            .ifBlank { "video" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "${base}_$stamp.$ext"
    }

    // ---------- Downloads ----------

    fun enqueue(uri: Uri, video: LinkCheck.Video): SavedVideo {
        val request = DownloadManager.Request(uri)
            .setTitle(video.fileName)
            .setDescription("Saving to Gallery › $ALBUM_NAME")
            .setMimeType(video.mimeType)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES, "$ALBUM_NAME/${video.fileName}")
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .addRequestHeader("User-Agent", USER_AGENT)
        val id = manager.enqueue(request)
        return SavedVideo(
            downloadId = id,
            title = video.fileName,
            sourceUrl = uri.toString(),
            createdAt = System.currentTimeMillis()
        )
    }

    /** Returns current status for each id, or null if the system couldn't be queried. */
    suspend fun query(ids: List<Long>): Map<Long, DownloadSnapshot>? = withContext(Dispatchers.IO) {
        if (ids.isEmpty()) return@withContext emptyMap()
        try {
            val result = mutableMapOf<Long, DownloadSnapshot>()
            manager.query(DownloadManager.Query().setFilterById(*ids.toLongArray()))?.use { c ->
                val idCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
                val statusCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                val reasonCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)
                val soFarCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                val totalCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val localCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)
                val mimeCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val state = when (c.getInt(statusCol)) {
                        DownloadManager.STATUS_RUNNING -> DownloadState.Running
                        DownloadManager.STATUS_PAUSED -> DownloadState.Paused
                        DownloadManager.STATUS_SUCCESSFUL -> DownloadState.Successful
                        DownloadManager.STATUS_FAILED -> DownloadState.Failed
                        else -> DownloadState.Pending
                    }
                    result[id] = DownloadSnapshot(
                        id = id,
                        state = state,
                        bytesDownloaded = c.getLong(soFarCol),
                        totalBytes = c.getLong(totalCol),
                        reason = c.getInt(reasonCol),
                        localUri = c.getString(localCol),
                        mimeType = c.getString(mimeCol)
                    )
                }
            }
            result
        } catch (_: Exception) {
            null
        }
    }

    /** Makes sure a finished video appears in the Gallery straight away. */
    fun scanIntoGallery(snapshot: DownloadSnapshot) {
        val path = snapshot.localUri?.let { Uri.parse(it).path } ?: return
        MediaScannerConnection.scanFile(appContext, arrayOf(path), arrayOf(snapshot.mimeType), null)
    }

    /** Cancels an active download, or deletes a finished video from the phone. */
    fun remove(downloadId: Long) {
        runCatching { manager.remove(downloadId) }
    }

    fun fileUri(downloadId: Long): Uri? = runCatching { manager.getUriForDownloadedFile(downloadId) }.getOrNull()

    fun mimeType(downloadId: Long): String? =
        runCatching { manager.getMimeTypeForDownloadedFile(downloadId) }.getOrNull()
}
